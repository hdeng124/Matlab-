function [node1 node2]=street2node(street)

node1=1;
node2=2;
switch street
    case 'J1'
        node1 = 1;
        node2 = 2;
    case 'J2'
        node1 = 2;
        node2 = 3;
    case 'J3'
        node1 = 3;
        node2 = 4;
    case 'J4'
        node1 = 4;
        node2 = 5;
    case 'J5'
        node1 = 22;
        node2 = 26;
    case 'J6'
        node1 = 26;
        node2 = 27;
    case 'J7'
        node1 = 8;
        node2 = 9;
    case 'J8'
        node1 = 9;
        node2 = 10;
    case 'J9'
        node1 = 10;
        node2 = 11;
    case 'J10'
        node1 = 6;
        node2 = 7;
    case 'J11'
        node1 = 7;
        node2 = 12;
    case 'J12'
        node1 = 12;
        node2 = 13;
    case 'J13'
        node1 = 13;
        node2 = 14;
    case 'J14'
        node1 = 14;
        node2 = 15;
    case 'J15'
        node1 = 15;
        node2 = 16;
    case 'J16'
        node1 = 17;
        node2 = 18;
    case 'J17'
        node1 = 18;
        node2 = 19;
    case 'J18'
        node1 = 19;
        node2 = 20;
    case 'J19'
        node1 = 2;
        node2 = 7;
    case 'J20'
        node1 = 22;
        node2 = 8;
    case 'J21'
        node1 = 8;
        node2 = 12;
    case 'J22'
        node1 = 12;
        node2 = 17;
    case 'J23'
        node1 = 17;
        node2 = 23;
    case 'J24'
        node1 = 9;
        node2 = 13;
    case 'J25'
        node1 = 13;
        node2 = 18;
    case 'J26'
        node1 = 18;
        node2 = 24;
    case 'J27'
        node1 = 3;
        node2 = 26;
    case 'J28'
        node1 = 26;
        node2 = 10;
    case 'J29'
        node1 = 10;
        node2 = 14;
    case 'J30'
        node1 = 14;
        node2 = 19;
    case 'J31'
        node1 = 19;
        node2 = 25;
    case 'J32'
        node1 = 4;
        node2 = 27;
    case 'J33'
        node1 = 27;
        node2 = 11;
    case 'J34'
        node1 = 11;
        node2 = 15;
    case 'J35'
        node1 = 15;
        node2 = 20;
    case 'J36'
        node1 = 20;
        node2 = 21;

end